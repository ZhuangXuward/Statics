import re
import os
import pandas as pd
import tushare
import math
import numpy as np
import scipy
from scipy import stats
from scipy.stats import pearsonr
import matplotlib.pyplot as plt

def getDailycost(high, low):
    "得到每日股价=（每日最低价+每日最高价）/2"
    result = high
    for i in range(0, len(high)):
        result[i] = (high[i] + low[i]) / 2
    return result

	#计算特征和类的平均值
def calcMean(x,y):
    sum_x = sum(x)
    sum_y = sum(y)
    n = len(x)
    x_mean = float(sum_x+0.0)/n
    y_mean = float(sum_y+0.0)/n
    return x_mean,y_mean

#计算Pearson系数
def calcPearson(x,y):
    x_mean,y_mean = calcMean(x,y)	#计算x,y向量平均值
    n = len(x)
    sumTop = 0.0
    sumBottom = 0.0
    x_pow = 0.0
    y_pow = 0.0
    for i in range(n):
        sumTop += (x[i]-x_mean)*(y[i]-y_mean)
    for i in range(n):
        x_pow += math.pow(x[i]-x_mean,2)
    for i in range(n):
        y_pow += math.pow(y[i]-y_mean,2)
    sumBottom = math.sqrt(x_pow*y_pow)
    p = sumTop/sumBottom
    return p



high, low = np.loadtxt('.\data\\000012.csv',delimiter=',',usecols=(3,4),unpack=True,skiprows=1)
volume = np.loadtxt('.\data\\000012.csv', delimiter=',', usecols=(5,), skiprows=1)


#得到每日股价result
result = getDailycost(high, low)

#p = calcPearson(result, volume)
#print("股价和成交量的Pearson系数：", p)
#print("股价和成交量的Spearman系数：", S)

r, p = pearsonr(result, volume)
print("\n股价和成交量的Pearson系数（p为显著性值）：")
print("r = ", r)
print("p = ", p)

'''
首先看显著性值，也就是sig值或称p值。
它是判断r值，也即相关系数有没有统计学意义的。
判定标准一般为0.05。
由表可知，两变量之间的相关性系数r=-0.035，
其p值为0.709>0.05,所以相关性系数没有统计学意义。
无论r值大小，都表明两者之间没有相关性。
如果p值<0.05，那么就表明两者之间有相关性。
然后再看r值，|r|值越大，相关性越好，正数指正相关，负数指负相关。
一般认为：
|r|大于等于0.8时为两变量间高度相关；
|r|大于等于0.5小于0.8时认为两变量中度相关；
|r|大于等于0.3小于0.5时认为两变量低度相关或弱相关，
|r|小于0.3说明相关程度为极弱相关或无相关。
所以判断相关性，先看p值，看有没有相关性。
再看r值，看相关性是强还是弱。
'''


#保存csv中提取的成交量
volume_csv=pd.read_csv('.\data\\000012.csv',usecols=(5,))

#将list类型的result中的内容转换到csv中，便于求解Spearman系数
list=result
name=['dailycost']
test=pd.DataFrame(columns=name,data=list)
test.to_csv('.\data\\test.csv')

#保存csv中提取的股价
result_csv=pd.read_csv('.\data\\test.csv',usecols=(1,))


Spearman = result_csv["dailycost"].corr(volume_csv["volume"])
print("\n股价和成交量的Spearman系数：\n", Spearman)





