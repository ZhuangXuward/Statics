import re
import os
import pandas as pd
import tushare
import numpy as np
from scipy import stats

def getDailycost(high, low):
    "得到每日股价=（每日最低价+每日最高价）/2"
    result = high
    for i in range(0, len(high)):
        result[i] = (high[i] + low[i]) / 2
    return result

def getAverage(value):
    "得到股价均值"
    sum = 0
    for i in range(0, len(value)):
        sum += value[i]
    sum /= len(value)
    return sum

def getMedian(value):
    "得到股价中位数"
    value.sort()
    leng = len(value)
    x1 = int((leng + 1) / 2)
    x2 = int(leng / 2 + 1)
    x3 = int(leng / 2)
    if(leng % 2 != 0):
        median = value[x1]
    else:
        median = (value[x2] + value[x3]) / 2
    return median



high, low = np.loadtxt('.\data\\000001.csv',delimiter=',',usecols=(3,4),unpack=True,skiprows=1)

#得到每日股价result
result = getDailycost(high, low)

average = getAverage(result)
print("000001的历史股价的日均值（自己的函数）：", average)

aver = np.mean(result)
print("000001的历史股价的日均值（numpy函数）：", aver)

median = getMedian(result)
print("000001的股价中位数（自己的函数）：", median)

a = np.array(result)
b = np.median(a)
print("000001的股价中位数（numpy函数）：", b)

PM25 = np.percentile(result, 25)
print("000001的股价0.25分位数：", PM25)

PM75 = np.percentile(result, 75)
print("000001的股价0.75分位数：", PM75)

var = np.var(result)
stdvar = np.std(result)
print("000001的股价方差：", var)
print("000001的股价标准差：", stdvar)

para = aver / stdvar
print("000001的股价变异系数：", para)

range = result.max() - result.min()
print("000001的股价极差：", range)
print("000001的股价四分位极差：", PM75 - PM25)

skew = stats.skew(result)
kurtosis = stats.kurtosis(result)
print("000001的股价偏度：", skew)
print("000001的股价峰度：", kurtosis)

'''
a = np.array(([1,2,3,4]))
b = np.median(a)
print(a, b)
'''

