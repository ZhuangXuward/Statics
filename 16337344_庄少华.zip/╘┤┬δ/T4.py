import os
import csv
import os.path
import re
import os
import pandas as pd
import tushare
import math
import numpy as np
import scipy
from scipy import stats
from scipy.stats import pearsonr
import matplotlib.pyplot as plt


#获得文件夹中所有文件的文件名
def file_name(file_dir):
    result = [1]*100
    i = 0
    for root, dirs, files in os.walk(file_dir):
        #print(root)  # 当前目录路径
        #print(dirs)  # 当前路径下所有子目录
        #print(files)  # 当前路径下所有非目录子文件
        result[i] = files
        i += 1
    return result


def getDate(csv_name):
    data = []
    for item in csv_name:
        data.append(item[0])
    del data[0]
    return data


def getSamedate(date = [], date2 = []):
    result = []
    for item in date:
        if item in date2:
            result.append(item)
    return result

def getDailycost(high, low):
    "得到每日股价=（每日最低价+每日最高价）/2"
    result = high
    for i in range(0, len(high)):
        result[i] = (high[i] + low[i]) / 2
    return result

def getCost(file_name):
    high, low = np.loadtxt('.\data\\' + file_name, delimiter=',', usecols=(3, 4), unpack=True, skiprows=1)
    # 得到每日股价result len(result) = 4341
    result = getDailycost(high, low)
    return result

def getHighest(dic = {}):
    return max(dic, key=dic.get)

def getLowest(dic = {}):
    return min(dic, key=dic.get)

key = 0
dic = {}; dicp = {}; dics = {}; dicps = {}
allname = file_name(".\data\\")
all_name = [1]*100
all_name = allname[0]
#获得data文件夹中所有csv文件的文件名，保存在all_name列表中


for cyc in range(0, 99):
    for becyc in range(cyc + 1, 100):
        #将csv整个传入csv_file中，每一行以一个list类型保存在大list中
        csv_file = csv.reader(open('.\data\\'+all_name[cyc]))
        csv_file2 = csv.reader(open('.\data\\'+all_name[becyc]))

        #获得csv中所有日期，并保存于date列表中
        date = getDate(csv_file)
        date2 = getDate(csv_file2)

        #获得1、2股中相同日期，存放于same_date列表中
        #same_date = getSamedate(date, date2)
        same_date = list(set(date).intersection(set(date2)))
        same_date.sort()

        #获得1股股价
        cost = getCost(all_name[cyc])
        #获得2股股价
        cost2 = getCost(all_name[becyc])

        #print(same_date)


        #存放两股相同日期的股价
        result = []; result2 = []
        for item in same_date:
            index = date.index(item)
            index2 = date2.index(item)
            result.append(cost[index])
            result2.append(cost2[index2])

        
        #计算两股相同日期股价的Pearson系数
        r, p = pearsonr(result, result2)
        rs, ps = spearmanr(result, result2)

        #get Pearson
        dic[all_name[cyc]+all_name[becyc]] = r
        dic[all_name[becyc]+all_name[cyc]] = r
        dicp[all_name[cyc] + all_name[becyc]] = p
        dicp[all_name[becyc] + all_name[cyc]] = p

        #get Spearman
        dics[all_name[cyc] + all_name[becyc]] = rs
        dics[all_name[becyc] + all_name[cyc]] = rs
        dicps[all_name[cyc] + all_name[becyc]] = ps
        dicps[all_name[becyc] + all_name[cyc]] = ps

count = 0
print("Pearson 相关性最强的5对")
for items in dic:
    if count == 5:
        break
    index = getHighest(dic)
    print("股票" + index + "的相关系数为：", dic[index], "p值为：", dicp[index])
    del dic[index]
    count += 1

count = 0
print("Pearson 相关性最弱的5对")
for items in dic:
    if count == 5:
        break
    index = getLowest(dic)
    print("股票" + index + "的相关系数为：", dic[index], "p值为：", dicp[index])
    del dic[index]
    count += 1

count = 0
print("Spearman 相关性最强的5对")
for items in dics:
    if count == 5:
        break
    index = getHighest(dics)
    print("股票" + index + "的相关系数为：", dics[index], "p值为：", dicps[index])
    del dics[index]
    count += 1

count = 0
print("Spearman 相关性最弱的5对")
for items in dics:
    if count == 5:
        break
    index = getLowest(dics)
    print("股票" + index + "的相关系数为：", dics[index], "p值为：", dicps[index])
    del dics[index]
    count += 1













