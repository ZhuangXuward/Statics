import re
import os
import pandas as pd
import tushare
import math
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

def getDailycost(high, low):
    "得到每日股价=（每日最低价+每日最高价）/2"
    result = high
    for i in range(0, len(high)):
        result[i] = (high[i] + low[i]) / 2
    return result

high, low = np.loadtxt('.\data\\000006.csv',delimiter=',',usecols=(3,4),unpack=True,skiprows=1)

#得到每日股价result
result = getDailycost(high, low)


x = np.arange(-5, 5, 0.1)
y = stats.norm.cdf(x, 0, 1)
plt.plot(x, y)
#plt.show() 标准正态分布的累积分布图

stats.probplot(result, dist="norm", plot=plt)
plt.show()#直接绘制qq图

