import re
import os
import pandas as pd
import tushare
import math
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

def getDailycost(high, low):
    "得到每日股价=（每日最低价+每日最高价）/2"
    result = high
    for i in range(0, len(high)):
        result[i] = (high[i] + low[i]) / 2
    return result

high, low = np.loadtxt('.\data\\000006.csv',delimiter=',',usecols=(3,4),unpack=True,skiprows=1)

#得到每日股价result
result = getDailycost(high, low)

leng = len(result)
leng_ = int(math.sqrt(leng))
bin = int(leng_)
print(result.max())

fig = plt.figure()
ax = fig.add_subplot(111)
ax.hist(result, bins = bin)
plt.title('Cost-fre')
plt.xlabel('Cost')
plt.ylabel('fre')
plt.show()



